package assignment2API;

import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class testcase1 {


    @Test
    public void getcall_TC01() {

        // Set the base URI
        RestAssured.baseURI = "https://swapi.dev/api/people/3/";

        // Send GET request to fetch the person details
        Response response = RestAssured.get();

        // Validate and print the status code
        int statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode, 200, "Status code is not as expected");
    }
    
    
    @Test
    public void postcall_TC02() {
        // Set the base URI
        RestAssured.baseURI = "https://swapi.dev/api/people/";
        
        // Send POST request
        Response response = RestAssured.post();

        // Validate and print the status code (expecting a code other than 200 since SWAPI is read-only)
        int statusCode = response.getStatusCode();
        Assert.assertNotEquals(statusCode, 200, "Status code should not be 200 for a POST request");
    }
    
    
    
    @Test
    public void putcall_TC03() {
        // Set the base URI
        RestAssured.baseURI = "https://swapi.dev/api/people/";
        
        // Send PUT request to create a new person
        Response response = RestAssured.put();

        // Validate and print the status code (expecting a code other than 200 since SWAPI is read-only)
        int statusCode = response.getStatusCode();
        Assert.assertNotEquals(statusCode, 200, "Status code should not be 200 for a POST request");
    }

    
    @Test
    public void deletecall_TC04() {
        // Set the base URI
        RestAssured.baseURI = "https://swapi.dev/api/people/";
        
        // Send DELETE request
        Response response = RestAssured.delete();

        // Validate and print the status code (expecting a code other than 200 since SWAPI is read-only)
        int statusCode = response.getStatusCode();
        Assert.assertNotEquals(statusCode, 200, "Status code should not be 200 for a POST request");
    }

}
